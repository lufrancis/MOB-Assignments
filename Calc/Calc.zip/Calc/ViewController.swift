//
//  ViewController.swift
//  Calc
//
//  Created by George Geicke on 6/7/15.
//  Copyright (c) 2015 George Geicke. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var labelDisplay: UILabel!
    var numberString: String = ""
    var decimalPressed: Bool = false
    
    var numberDouble: Double = 0.0
    
    var numberOne: Double = 0.0
//    var numberTwo: Double = 0.0
    
    var operatorSign: String = ""
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func displayLabel (numberDouble: Double)  {
        

        var formatter = NSNumberFormatter()
        formatter.numberStyle = NSNumberFormatterStyle.DecimalStyle
        
        labelDisplay.text = formatter.stringFromNumber(numberDouble)
        
    }
    
    func numberPressed (inputString:String) {
        if numberString == "0" {
            numberString = inputString
        } else {

        numberString = numberString + inputString
        }
        labelDisplay.text = numberString
        println(numberString)
        numberDouble = NSNumberFormatter().numberFromString(numberString)!.doubleValue
        displayLabel(numberDouble)
        
    
    }

    func calculate () {
        if operatorSign != "" {
            if operatorSign == "+" {
                numberOne = (numberOne + numberDouble)
            }
            else if operatorSign == "-" {
                numberOne = (numberOne - numberDouble)
            }
            else if operatorSign == "x" {
                numberOne = (numberOne * numberDouble)
            }
            else if operatorSign == "/" {
                numberOne = (numberOne / numberDouble)
            }
            
        }
        else {
            numberOne = numberDouble
        }
    }


    
    @IBAction func ACClicked(sender: AnyObject) {
        numberDouble = NSNumberFormatter().numberFromString(numberString)!.doubleValue
        numberDouble = 0.0
        numberString = String(format: "%f", numberDouble)
        labelDisplay.text = String(format: "%f", numberDouble)
    }
    
    @IBAction func SignClicked(sender: AnyObject) {
        numberDouble = NSNumberFormatter().numberFromString(numberString)!.doubleValue
        numberDouble = numberDouble * -1
        numberString = String(format: "%f", numberDouble)
        displayLabel(numberDouble)

    
    }
    
    @IBAction func PercentageClicked(sender: AnyObject) {
        if operatorSign == "=" {
            numberString = labelDisplay.text!
        }
        numberDouble = NSNumberFormatter().numberFromString(numberString)!.doubleValue
        numberDouble = numberDouble / 100
        numberString = String(format: "%f", numberDouble)
        displayLabel(numberDouble)
        
        
        
    }
    
    @IBAction func DivideClicked(sender: AnyObject) {
        if operatorSign == "=" {
            numberString = labelDisplay.text!
        }
        numberDouble = NSNumberFormatter().numberFromString(numberString)!.doubleValue
        calculate()
        operatorSign = "/"
        numberString = ""
        decimalPressed = false
        println(String(format: "%f", numberOne))
        //labelDisplay.text = String(format: "%f", numberOne)
        displayLabel(numberOne)
    }
    

    @IBAction func MultipliedClicked(sender: AnyObject) {
        if operatorSign == "=" {
            numberString = labelDisplay.text!
        }
        numberDouble = NSNumberFormatter().numberFromString(numberString)!.doubleValue
        calculate()
        operatorSign = "x"
        numberString = ""
        decimalPressed = false
        println(String(format: "%f", numberOne))
        displayLabel(numberDouble)
    }
    
    @IBAction func MinusClicked(sender: AnyObject) {
        if operatorSign == "=" {
            numberString = labelDisplay.text!
        }
        numberDouble = NSNumberFormatter().numberFromString(numberString)!.doubleValue
        calculate()
        operatorSign = "-"
        numberString = ""
        decimalPressed = false
        println(String(format: "%f", numberOne))
        displayLabel(numberOne)
        
        
    }
    
    @IBAction func PlusClicked(sender: AnyObject) {
//        if numberDouble != 0.0 {
        if operatorSign == "=" {
            numberString = labelDisplay.text!
        }
        numberDouble = NSNumberFormatter().numberFromString(numberString)!.doubleValue
//        }
        calculate()
        operatorSign = "+"
        numberString = ""
        decimalPressed = false
        println(String(format: "%f", numberOne))
        displayLabel(numberOne)
     
    }
    
    @IBAction func EqualClicked(sender: AnyObject) {
        if operatorSign == "=" {
            numberString = labelDisplay.text!
        }
        numberDouble = NSNumberFormatter().numberFromString(numberString)!.doubleValue
        calculate()
        operatorSign = "="
        numberString = "0"
        println(String(format: "%f", numberOne))
//        labelDisplay.text = String(format: "%f", numberOne)
        
displayLabel(numberOne)
        
        
    }
    
    @IBAction func DecimalClicked(sender: AnyObject) {
                  if decimalPressed == false {
                numberString = numberString + "."
                labelDisplay.text = numberString
                decimalPressed = true
        }
        
        
    }
    
    
    @IBAction func ZeroClicked(sender: AnyObject) {
        numberPressed("0")
    }
    
    @IBAction func OneClicked(sender: AnyObject) {
        numberPressed("1")
    }
    
    
    @IBAction func TwoClicked(sender: AnyObject) {
        numberPressed("2")
    }
    

    @IBAction func ThreeClicked(sender: AnyObject) {
        numberPressed("3")
    }
   
    @IBAction func FourClicked(sender: AnyObject) {
        numberPressed("4")
    }
    
    
    @IBAction func FiveClicked(sender: AnyObject) {
        numberPressed("5")
    }
    
    
    @IBAction func SixClicked(sender: AnyObject) {
        numberPressed("6")
    }

    @IBAction func Clicked(sender: AnyObject) {
        numberPressed("7")
    }
    
    @IBAction func EightClicked(sender: AnyObject) {
        numberPressed("8")
    }
    
    @IBAction func NineClicked(sender: AnyObject) {
        numberPressed("9")
    }

    
}

